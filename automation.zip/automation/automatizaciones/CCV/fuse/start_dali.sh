#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_dali.sh
#%
#% DESCRIPTION
#%     Script para levantar repositorios drt_dali
#% PARAMETERS: 
#%      In:
#%			PARAM $1:
#%				1: procesa DRT_DALI 1		
#%				2: procesa DRT_DALI 2		
#%				3: procesa DRT_DALI 3		
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_dali.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 

numeroproceso="$1"

#================================================================
# Validacion de parametros
#================================================================

if [ -z  "${numeroproceso}" ]; then
	echo "Falta proporcionar un parameteo que sea 1 o 2 o 3" 
	echo "Ejemplo: start_dali.sh 1 " 
	exit 1
fi

if [ "${numeroproceso}" -gt 4 ];then
	echo "Parametro invalido solo es del 1 o 2 o 3 " 
	exit 1
fi

if [ $numeroproceso -gt 1 ]; then
	rutainicial=`dirname ../` 
	cd $rutainicial
	cd ..	
fi


rutainicial=`pwd`
. common/setenv.sh

#rutainicial=`dirname ../`
#. $rutainicial/common/setenv.sh

echo "===================================================" 
echo "VALIDANDO SI HAY PROCESO LEVANTADO DRT_DALI$numeroproceso: "		   
date 													   
echo "===================================================" 

nombreproceso="${buscaproc}${numeroproceso}_*"

#================================================================
# Validamos que no haya servicios colgados en el server
#================================================================
PIDS=`ps -fea | grep $nombreproceso |  grep -v 'grep'  | awk '{ print $2 }'`
echo "$PIDS" | while read PID; do
	if [ -n  "$PID" ]; then
		echo "ELIMINANDO SERVICIO DRT_DALI$numeroproceso CON PID: $PID"
		kill -9 "$PID"		
		sleep 1
	fi	
done

echo "===================================================" 
echo "TERMINA SI HAY PROCESO LEVANTADO DRT_DALI $numeroproceso: "		   
date 													   
echo "===================================================" 

echo ""
echo ""
echo ""

#================================================================
# Se inicia proceso para levantar servicio
#================================================================


echo "===================================================" 
echo "INICIANDO CON PROCESO PARA LEVANTAR DRT_DALI$numeroproceso  EN FECHA: " 
date 													   
echo "===================================================" 

echo "Comando a ejecutar: " $startdali$numeroproceso$startcomplemento 


PIDHOST=`ps -fea | grep $nombreproceso |  grep -v 'grep'  | awk '{ print $2 }'`
if [ -z "$PIDHOST" ] 
	then
	echo "Se ejecuta comando start" 
	
	$startdali$numeroproceso$startcomplemento

	ATTEMPTS=0
	MAX_ATTEMPTS=20
	while [ -z "$PID"  ]
	do
		sleep 1
		PID=`ps -fea | grep $nombreproceso |  grep -v 'grep'  | awk '{ print $2 }'`
		ATTEMPTS=$(( $ATTEMPTS + 1 ))
		echo "WAITING $ATTEMPTS SEC"
		if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
			then
			
			PID='-10000'
			salida=1
		fi
	done
else 
	
	salida=0
fi

#================================================================
# Se termina proceso para levantar servicio y validamos si fue exitoso
#================================================================

if [ "$salida" -eq 0 ]; then
	
	echo "===================================================" 
	echo "El Contenedor drt_dali Levanto Correctamente" 
	date 													   
	echo "===================================================" 
	
else
	echo "===================================================" 
	echo "Ocurrio un Error al levantar el Contenedor drt_dali " 
	date 													   
	echo "===================================================" 

fi

echo "" 
echo "" 
echo "" 
exit $salida



