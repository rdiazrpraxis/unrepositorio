#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    setenv.sh
#%
#% DESCRIPTION
#%     Shell encargado de inicializar variables
#%			  
#================================================================
#- IMPLEMENTATION
#-    version         setenv.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation
# 




#################
##LEVANTA DALI
export IP_DALI_1="192.168.201.103"
export IP_DALI_2="192.168.201.104"
export IP_DALI_3="192.168.201.105"
export startdali="/soft/app/fuseusr/jboss-fuse-6.2.1/instances/drt_dali"
export startcomplemento="_*/bin/start"
export levantadali="start_dali.sh"
export usuario="fuseusr"
export buscaproc="drt_dali"

export JAVA_HOME="/usr/local/java/jdk1.8.0_221"
export rutaincial="$rutainicial"
export rutafuse="$rutaincial/fuse"
export LOG_DALI="$rutaincial/start_drt_dali.log"
export pathremoto="$rutainicial"
export rutafuseremoto="$pathremoto/fuse"


#################
##DETENER DALI
export detienedali="stop_dali.sh"
export LOG_DETIENE_DALI="$rutaincial/stop_drt_dali.log"
export stopdali="/soft/app/fuseusr/jboss-fuse-6.2.1/instances/drt_dali"
export stopcomplemento="_*/bin/stop"
