#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_drt_dali.sh
#%
#% DESCRIPTION
#%     Script para levantar repositorios drt_dali
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_drt_dali.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 


rutainicial=`dirname $0` 
cd $rutainicial
rutainicial=`pwd`
. common/setenv.sh



#================================================================
# inicia dali 3
#================================================================


ssh $usuario@$IP_DALI_3 $rutafuseremoto/$levantadali 3 &>> $LOG_DALI
starthost=$?

if [ "$starthost" -ne "0" ] 
then
	echo "$starthost"
	exit 1
fi
#================================================================
# Termina dali 3
#================================================================



#================================================================
# Inicia dali 1
#================================================================

$rutafuse/$levantadali 1 &>> $LOG_DALI
starthost=$?

if [ "$starthost" -ne "0" ] 
then
	echo " $starthost"
	exit 1
fi

#================================================================
# Termina dali 1
#================================================================



#================================================================
# inicia dali 2
#================================================================

ssh $usuario@$IP_DALI_2 $rutafuseremoto/$levantadali 2 &>> $LOG_DALI
starthost=$?

if [ "$starthost" -ne "0" ] 
then
	echo "$starthost"
	exit 1
fi

#================================================================
# Termina dali 2
#================================================================
