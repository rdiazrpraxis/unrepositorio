#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_drt_dali.sh
#%
#% DESCRIPTION
#%     Script para detener repositorios drt_dali
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_drt_dali.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 

###Directorio Principal

BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno

. $BASEDIR/common/setenv.sh

#rutainicial=`dirname $0` 
#cd $rutainicial
#rutainicial=`pwd`
#. common/setenv.sh



#================================================================
# inicia dali 3
#================================================================


ssh $USUARIO@$IP_DALI_3 $RUTAFUSEREMOTO/$DETIENEDALI 3 &>> $LOG_DETIENE_DALI
stophost=$?

if [ "$stophost" -ne "0" ] 
then
	echo "$stophost"
	exit 1
fi
#================================================================
# Termina dali 3
#================================================================



#================================================================
# Inicia dali 1
#================================================================


$RUTAFUSE/$DETIENEDALI 1 &>> $LOG_DETIENE_DALI
stophost=$?

if [ "$stophost" -ne "0" ] 
then
	echo " $stophost"
	exit 1
fi

#================================================================
# Termina dali 1
#================================================================



#================================================================
# inicia dali 2
#================================================================

ssh $USUARIO@$IP_DALI_2 $RUTAFUSEREMOTO/$DETIENEDALI 2 &>> $LOG_DETIENE_DALI
stophost=$?

if [ "$stophost" -ne "0" ] 
then
	echo "$stophost"
	exit 1
fi

#================================================================
# Termina dali 2
#================================================================
