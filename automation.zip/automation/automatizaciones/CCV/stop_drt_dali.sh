#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_drt_dali.sh
#%
#% DESCRIPTION
#%     Script para detener repositorios drt_dali
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_drt_dali.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 


rutainicial=`dirname $0` 
cd $rutainicial
rutainicial=`pwd`
. common/setenv.sh



#================================================================
# inicia dali 3
#================================================================


ssh $usuario@$IP_DALI_3 $rutafuseremoto/$detienedali 3 &>> $LOG_DETIENE_DALI
stophost=$?

if [ "$stophost" -ne "0" ] 
then
	echo "$stophost"
	exit 1
fi
#================================================================
# Termina dali 3
#================================================================



#================================================================
# Inicia dali 1
#================================================================


$rutafuse/$detienedali 1 &>> $LOG_DETIENE_DALI
stophost=$?

if [ "$stophost" -ne "0" ] 
then
	echo " $stophost"
	exit 1
fi

#================================================================
# Termina dali 1
#================================================================



#================================================================
# inicia dali 2
#================================================================
echo "ssh $usuario@$IP_DALI_2 $rutafuseremoto/$detienedali 2 &>> $LOG_DETIENE_DALI"
ssh $usuario@$IP_DALI_2 $rutafuseremoto/$detienedali 2 &>> $LOG_DETIENE_DALI
stophost=$?

if [ "$stophost" -ne "0" ] 
then
	echo "$stophost"
	exit 1
fi

#================================================================
# Termina dali 2
#================================================================
