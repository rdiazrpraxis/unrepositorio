#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_ctl_inventarios.sh
#%
#% DESCRIPTION
#%     Script para levantar el servicio de control inventarios
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_ctl_inventarios.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 

BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIALINVENTARIOS=`pwd`

. $BASEDIR/common/setenv.sh


#================================================================
# Inicia Levantar control de inventarios
#================================================================

$ARCHIVOSINVENTARIOSTART &>> $LOG_INVENTARIOS_START
RESPINV=$?
if [ "$RESPINV" -ne "0" ] 
then
	echo "$RESPINV"
	exit 1
fi
