#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_jboss_eap4.sh
#%
#% DESCRIPTION
#%     Script para detener JBOSS
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_jboss_eap4.sh  0.0.0
#-    author          Eric Alejandro Macías Moreno
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : mzme@praxisglobe.com : Script creation 
# 

#================================================================
#	DETIENE PROCESO JBOSS
#================================================================
BASEDIR=$(dirname $(readlink -f $0))

. $BASEDIR/common/setenv.sh

echo "===================================================" &>> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4
echo "              Deteniendo  Proceso  JBOSS 4             " &>> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4
echo "                                                   " &>> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4
echo "Script detiene proceso JBOSS inicia: - "$(date) >> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4
echo "                                                  " &>> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4

$BASEDIR/jboss/$STOP_SERVICE_JBOSS_EAP4 &>> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4
resultado=$?

#VALIDA SI PROCESO SE EJECUTA CON EXITO
if [[ $resultado -eq 0 ]]
  then
    echo "Proceso terminado con exito - "$(date) >> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4
    exit 0
  else
    echo "Proceso terminado sin exito - "$(date) >> $BASEDIR/log/$LOG_STOP_SERVICE_JBOSS_EAP4
    exit 1
fi
