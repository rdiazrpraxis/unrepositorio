#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_ctl_inventarios.sh
#%
#% DESCRIPTION
#%     Script para detener el servicio de control inventarios
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         run_workaround.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 

BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIALINVENTARIOS=`pwd`

. $BASEDIR/common/setenv.sh


#================================================================
# Inicia Detener control de inventarios
#================================================================

$ARCHIVOSINVENTARIOSTOP &>> $LOG_INVENTARIOS_STOP
RESPINV=$?
if [ "$RESPINV" -ne "0" ] 
then
	echo "$RESPINV"
	exit 1
fi