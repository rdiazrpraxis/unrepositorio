#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    setenv.sh
#%
#% DESCRIPTION
#%     Shell encargado de inicializar variables
#%                        
#================================================================


#################
##LEVANTA JBOSS
export IP_HOST_A="192.168.96.128"
export IP_HOST_B="192.168.96.128"
export IP_HOST_C="192.168.96.128"
export IP_HOST_D="192.168.96.128"
export HOST_A="A"
export HOST_B="B"
export HOST_C="C"
export HOST_D="D"
export RUTAINICIAL="$RUTAINICIAL"
export USUARIO="rdiazr"
export RUTAJBOSS="$RUTAINICIAL/jboss"
export LEVANTAJBOOS="start_host.sh"
export LOG_START="$RUTAINICIAL/log/start_host.log"
export ARCHIVOSTART="Host-Dali-Web-$HOST.sh"
export COMANDOSTART="/soft/app/indeval/bin/$ARCHIVOSTART start"
export JAVA_HOME="/usr/local/java/jdk1.7.0_80"
export BUSCAJAVA="java"
export VALIDAJBOSS="$RUTAJBOSS/validacioninstanciasjboss.sh"


#################
##VARIABLES DE PROCESOS
export PROCESOHOST="Host-Dali-Web-$HOST"
export CONTROLPROCESO="'Process Controller'"
export CONTROLHOST="'Host Controller'"
export PROCESOSA="serv-int-A1 
	serv-pfi-A1 
	serv-pfi-ent-A1 
	serv-portal-A1 
	serv-preliq-A1 
	serv-va-A1 
	serv-seg-A1
	"
export PROCESOSB="serv-con-B 
	serv-ing-B1 
	serv-mav-B1 
	serv-msj-swift-B1 
	serv-pfi-B1 
	serv-portal-B1 
	serv-seg-B1 
	serv-sing-portal-B1 
	serv-sing-quartz-B1
	"
	
export PROCESOSC="serv-mav-C1 
	serv-pfi-C1 
	serv-pfi-ent-C1 
	serv-portal-C1 
	serv-preliq-C1 
	serv-rep-C1 
	serv-va-C1
	"
	
export PROCESOSD="serv-ing-D1 
	serv-liq-sing-D1 
	serv-msj-swift-D1 
	serv-pfi-D1 
	serv-portal-D1 
	serv-rep-D1 
	serv-va-D1
	"
	

#################
##VARIABLES PARA COMANDO JBOSS
export HOME_JBOSS="/home/rdiazr"
export JBOSS_CONTROLLER="CONTROLER"
export JBOSS_USER="USUARIOJBOSS"	
export JBOSS_PASS="PASSW"
export INTENTOS=0
export LIMITEINTENTOS=50