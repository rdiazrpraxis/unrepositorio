#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    setenv.sh
#%
#% DESCRIPTION
#%     Shell encargado de inicializar variables
#%			  
#================================================================


#################
##VARIABLES CONTROL INVENTARIOS INDEVAL	


JAVA_HOME="/usr/local/java/jdk1.7.0_80/"
export RUTAINICIALINVENTARIOS="$RUTAINICIALINVENTARIOS"

export LOG_INVENTARIOS_START="$RUTAINICIALINVENTARIOS/log/start_ctl_inventarios.log"
export ARCHIVOSINVENTARIOSTART="$RUTAINICIALINVENTARIOS/jboss/start_ctl_inventarios.sh"
export ARCHIVO_STAR_INVENTARIO="startInventarios.sh"
export RUTA_INVENTARIO_START="/soft/app/jboss-eap-6.4/bin"
#export RUTA_INVENTARIO_START="/home/rdiazr"

export EJECUCION_INVENTARIO_START="$RUTA_INVENTARIO_START/$ARCHIVO_STAR_INVENTARIO"
export PROCESOSSTANDALONEINVENTARIO="standalone"

export ARCHIVOSINVENTARIOSTOP="$RUTAINICIALINVENTARIOS/jboss/stop_ctl_inventarios.sh"
export LOG_INVENTARIOS_STOP="$RUTAINICIALINVENTARIOS/log/stop_ctl_inventarios.log"