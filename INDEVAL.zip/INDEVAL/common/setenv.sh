#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    setenv.sh
#%
#% DESCRIPTION
#%     Shell encargado de inicializar variables
#%			  
#================================================================


#################
##VARIABLES WORKARROUND

##VARIABLES PARA COMANDO JBOSS
export HOME_JBOSS="/home/rdiazr"
export JBOSS_CONTROLLER="CONTROLER"
export JBOSS_USER="USUARIOJBOSS"	
export JBOSS_PASS="PASSW"




JAVA_HOME="/usr/local/java/jdk1.7.0_80/"
export INSTANCIA_C="192.168.96.128"
export USUARIOINSTANCIA_C="webuser"
export USUARIOINSTANCIA_C="rdiazr"

export RUTAINICIALWORKARROUND="$RUTAINICIALWORKARROUND"
export RUTA_WORKARROUND_JBOSS="$RUTAINICIALWORKARROUND/jboss"
export LOG_WORKARROUND="$RUTAINICIALWORKARROUND/log/run_workaround.log"
export ARCHIVOFASE0="$RUTA_WORKARROUND_JBOSS/run_workaround_face0.sh"
export ARCHIVOFASE0_1="$RUTAINICIALWORKARROUND/run_workaround_face0_1.sh"
export ARCHIVOFASE1="$RUTA_WORKARROUND_JBOSS/run_workaround_face1.sh"
export ARCHIVOFASE2="$RUTA_WORKARROUND_JBOSS/run_workaround_face2.sh"

export DETIENEINSTANCIAS="/server-group=grupo-preliquidacion:stop-servers"
export PROCESOINSTANCIA_A="serv-preliq-A1"
export PROCESOINSTANCIA_C="serv-preliq-C1"

export START_A_FASE1="/host=Host-Dali-Web-A/server-config=serv-preliq-A1:start"
export ESTATUS_A_FASE1="/host=Host-Dali-Web-A/server-config=serv-preliq-A1:start"


export START_A_FASE2="/host=Host-Dali-Web-A/server-config=serv-preliq-A1:start"
export ESTATUS_C_FASE2="/host=Host-Dali-Web-A/server-config=serv-preliq-A1:start"
