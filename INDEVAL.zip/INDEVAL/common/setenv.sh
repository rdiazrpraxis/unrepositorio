#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    setenv.sh
#%
#% DESCRIPTION
#%     Shell encargado de inicializar variables
#%			  
#================================================================

######################################################
########Variables Jboss

################ JBOSS 4
export LOG_START_SERVICE_JBOSS_EAP4=start_jboss_eap4.log
export LOG_STOP_SERVICE_JBOSS_EAP4=stop_jboss_eap4.log

export START_SERVICE_JBOSS_EAP4=start_jboss_eap4.sh
export STOP_SERVICE_JBOSS_EAP4=stop_jboss_eap4.sh
                                 
export START_PROCESS_JBOSS=/soft/app/jboss-eap-4.2/jboss-as/bin/startSegConsola.sh
export CCV_PROCESS_JBOSS=seg-console

#####=====================================================================


#################
##VARIABLES PARA COMANDO JBOSS
export HOME_JBOSS="/home/rdiazr"
export JBOSS_CONTROLLER="CONTROLER"
export JBOSS_USER="USUARIOJBOSS"	
export JBOSS_PASS="PASSW"
export INTENTOS=0
export LIMITEINTENTOS=50


#################
##LEVANTA JBOSS
export IP_HOST_A="192.168.96.128"
export IP_HOST_B="192.168.96.128"
export IP_HOST_C="192.168.96.128"
export IP_HOST_D="192.168.96.128"
export HOST_A="A"
export HOST_B="B"
export HOST_C="C"
export HOST_D="D"
export RUTAINICIAL="$RUTAINICIAL"
export USUARIO="webuser"
export RUTAJBOSS="$RUTAINICIAL/jboss"
export LEVANTAJBOOS="start_host.sh"
export LOG_START="$RUTAINICIAL/log/start_jboss_eap.log"
export ARCHIVOSTART="Host-Dali-Web-$HOST.sh"
export RUTACOMANDOS="/soft/app/indeval/bin"
#export RUTACOMANDOS="/home/rdiazr"
export COMANDOSTART="$RUTACOMANDOS/$ARCHIVOSTART start"
export JAVA_HOME="/usr/local/java/jdk1.7.0_80"
export BUSCAJAVA="java"
export VALIDAJBOSS="$RUTAJBOSS/validacioninstanciasjboss.sh"

export COMANDO_START_HOST_A=/soft/app/indeval/bin/Host-Dali-Web-A.sh\ start
export COMANDO_START_HOST_B=/soft/app/indeval/bin/Host-Dali-Web-B.sh\ start
export COMANDO_START_HOST_C=/soft/app/indeval/bin/Host-Dali-Web-C.sh\ start
export COMANDO_START_HOST_D=/soft/app/indeval/bin/Host-Dali-Web-D.sh\ start


#################
##VARIABLES DE PROCESOS
export PROCESOHOST="Host-Dali-Web-$HOST"
export CONTROLPROCESO="Process Controller"
export CONTROLHOST="Host Controller"
export PROCESOSA="serv-int-A1 
	serv-pfi-A1 
	serv-pfi-ent-A1 
	serv-portal-A1 
	serv-preliq-A1 
	serv-va-A1 
	serv-seg-A1
	"
export PROCESOSB="serv-con-B 
	serv-ing-B1 
	serv-mav-B1 
	serv-msj-swift-B1 
	serv-pfi-B1 
	serv-portal-B1 
	serv-seg-B1 
	serv-sing-portal-B1 
	serv-sing-quartz-B1
	"
	
export PROCESOSC="serv-mav-C1 
	serv-pfi-C1 
	serv-pfi-ent-C1 
	serv-portal-C1 
	serv-preliq-C1 
	serv-rep-C1 
	serv-va-C1
	"
	
export PROCESOSD="serv-ing-D1 
	serv-liq-sing-D1 
	serv-msj-swift-D1 
	serv-pfi-D1 
	serv-portal-D1 
	serv-rep-D1 
	serv-va-D1
	"
	

##############################################################################

export LOG_STOP_INDEVAL=log/stop_jboss_eap.log
export JBOSSEAP_HOST_SCRIPT_STOP=jboss/stop_host.sh
export HOST_A=A
export HOST_B=B
export HOST_C=C
export HOST_D=D
export HOST_DALI_WEB=Host-Dali-Web-
export PROCESS_CONTROLLER=Process\ Controller
export HOST_CONTROLLER=Host\ Controller
export COMANDO_STOP_HOST_A=/soft/app/indeval/bin/Host-Dali-Web-A.sh\ stop
export PROCESOS_HOST_A="serv-int-A1|serv-pfi-A1|serv-pfi-ent-A1|serv-portal-A1|serv-preliq-A1|serv-va-A1|serv-seg-A1"
export COMANDO_STOP_HOST_B=/soft/app/indeval/bin/Host-Dali-Web-B.sh\ stop
export PROCESOS_HOST_B="serv-con-B|serv-ing-B1|serv-mav-B1|serv-msj-swift-B1|serv-pfi-B1|serv-portal-B1|serv-seg-B1|serv-sing-portal-B1|serv-sing-quartz-B1"
export COMANDO_STOP_HOST_C=/soft/app/indeval/bin/Host-Dali-Web-C.sh\ stop
export PROCESOS_HOST_C="serv-mav-C1|serv-pfi-C1|serv-pfi-ent-C1|serv-portal-C1|serv-preliq-C1|serv-rep-C1|serv-va-C1"
export COMANDO_STOP_HOST_D=/soft/app/indeval/bin/Host-Dali-Web-D.sh\ stop
export PROCESOS_HOST_D="serv-ing-D1|serv-liq-sing-D1|serv-msj-swift-D1|serv-pfi-D1|serv-portal-D1|serv-rep-D1|serv-va-D1"





#################
##VARIABLES SAG
export USUARIO_SAG="swnet"
export RUTAINICIAL="$RUTAINICIAL"
export FOLDERSAG="$RUTAINICIAL/SAG"
export LOG_START_SAG="$RUTAINICIAL/SAG/log/start_sag.log"
export LOG_STOP_SAG="$RUTAINICIAL/SAG/log/stop_sag.log"
export ARCHIVO_START="$FOLDERSAG/start_sag.sh"
export ARCHIVO_STOP="$FOLDERSAG/stop_sag.sh"
export ESTATUS_STOP="stopped"
export ESTATUS_START="started"
export COMAND0SPROCESOS="/Alliance/Gateway/bin"
#export COMAND0SPROCESOS="/home/rdiazr"
export PRIMER_START="$COMAND0SPROCESOS/sag_system -block -- start"
export SEGUNDO_START="$COMAND0SPROCESOS/sag_bootstrap start"
export VALIDACION_STATUS="$COMAND0SPROCESOS/sag_system -block -- status"
export TIEMPOSLEEP=30s
export ESTATUS_EXCEPTION="Exception"

export PRIMER_STOP="$COMAND0SPROCESOS/sag_system -block -- stop"
export SEGUNDO_STOP="$COMAND0SPROCESOS/sag_bootstrap stop"

