#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_sag.sh
#%
#% DESCRIPTION
#%     Script para Dar de baja el SAG
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_sag.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 
BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/../common/setenv.sh

#================================================================
# funcion para validacion se estatus de la aplicacion
#================================================================

obtenestatus()
{	
	estatus=`$VALIDACION_STATUS`
	echo "$estatus"
}


validacionstatus()
{
	buscastatus="$1"
	estatus=`$VALIDACION_STATUS`
	estatustmp=`echo "$estatus" | grep "$buscastatus"`
	if [ "$estatustmp" != "" ]; then
		return 0
	else 
		return 1
	fi
	
}

iniciproceso()
{
	status=$(obtenestatus)
	estatustmp=`echo "$status" | grep "$ESTATUS_STOP"`
	if [ "$estatustmp" != "" ]; then
		echo "===================================================" 
		echo "EL PROCESO DE SAG YA ESTA ABAJO" 
		date 													   
		echo "==================================================="
		exit 0
	fi
	
	estatustmp=`echo "$status" | grep "$ESTATUS_START"`
	if [ "$estatustmp" != "" ]; then
		echo "===================================================" 
		echo "SE EJECUTA COMANDO: $PRIMER_STOP" 
		date 													   
		echo "==================================================="	
		$PRIMER_STOP

	fi
	estatustmp=`echo "$status" | grep "$ESTATUS_EXCEPTION"`
	if [ "$estatustmp" != "" ]; then
		echo "===================================================" 
		echo "SE EJECUTA COMANDO: $SEGUNDO_START" 
		date 													   
		echo "==================================================="	
		
		$SEGUNDO_START	
		sleep $TIEMPOSLEEP
		
		echo "===================================================" 
		echo "SE EJECUTA COMANDO: $PRIMER_STOP" 
		date 													   
		echo "==================================================="	
		$PRIMER_STOP	
	fi
	
}


#================================================================
# Inicio de validacion de Start SAG
#================================================================
echo "===================================================" 
echo "INICIA EL PROCESO DE STOP PARA PROCESO SAG" 
date 													   
echo "==================================================="
iniciproceso


#================================================================
# Inicializando variables
#================================================================
respuesta=1
timesleep=$TIEMPOSLEEP
numpausas=1

while [ $respuesta -eq 1 ]
do	


	sleep $timesleep
	echo "===================================================" 
	echo "ITERACION: $numpausas" 
	date 													   
	echo "==================================================="	
	
	if [ $numpausas -eq 6 ]; then	
		echo "===================================================" 
		echo "HAN PASADO 3 MINUTOS SE PROCEDE A EJECUTA COMANDO: $PRIMER_STOP" 
		date 													   
		echo "==================================================="	
		$PRIMER_STOP
	fi	
	
	if [ $numpausas -ge 10 ]; then
		echo "===================================================" 
		echo "TIEMPO EXCEDIDO AL DAR DE BAJA SAG" 
		date 													   
		echo "==================================================="
		exit 1
	fi
	
	validacionstatus "$ESTATUS_STOP" 
	respuesta=$?
	numpausas=$((numpausas+1))
	
done

#================================================================
# Finalizacion exitosa del servicio
#================================================================
echo "===================================================" 
echo "EL PROCESO DE SAG DETUVO DE MANERA CORRECTA" 
date 													   
echo "==================================================="

exit 0
