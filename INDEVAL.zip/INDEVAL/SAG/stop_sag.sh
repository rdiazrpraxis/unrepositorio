#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_sag.sh
#%
#% DESCRIPTION
#%     Script para Dar de baja el SAG
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_jboss_eap.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 
BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/common/setenv.sh