#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_sag.sh
#%
#% DESCRIPTION
#%     Script para lavantar el SAG
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_sag.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 

BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/../common/setenv.sh


#================================================================
# funcion para validacion se estatus de la aplicacion
#================================================================

obtenestatus()
{	
	estatus=`$VALIDACION_STATUS`
	echo "$estatus"
}


validacionstatus()
{
	buscastatus="$1"
	estatus=$(obtenestatus)
	estatustmp=`echo "$estatus" | grep "$buscastatus"`
	if [ "$estatustmp" != "" ]; then
		return 0
	else 
		return 1
	fi
	
}


iniciproceso()
{
	status=$(obtenestatus)
	estatustmp=`echo "$status" | grep "$ESTATUS_START"`
	if [ "$estatustmp" != "" ]; then
		echo "===================================================" 
		echo "EL PROCESO DE SAG YA ESTA ARRIBA" 
		date 													   
		echo "==================================================="
		exit 0
	fi
	
	estatustmp=`echo "$status" | grep "$ESTATUS_STOP"`
	if [ "$estatustmp" != "" ]; then
		echo "===================================================" 
		echo "SE EJECUTA COMANDO: $PRIMER_START" 
		date 													   
		echo "==================================================="	
		$PRIMER_START	

	fi
	estatustmp=`echo "$status" | grep "$ESTATUS_EXCEPTION"`
	if [ "$estatustmp" != "" ]; then
		echo "===================================================" 
		echo "SE EJECUTA COMANDO: $SEGUNDO_START" 
		date 													   
		echo "==================================================="	
		
		$SEGUNDO_START	
		sleep $TIEMPOSLEEP
		
		echo "===================================================" 
		echo "SE EJECUTA COMANDO: $PRIMER_START" 
		date 													   
		echo "==================================================="	
		$PRIMER_START	
	fi
	
}

#================================================================
# Inicio de validacion de Start SAG
#================================================================
echo "===================================================" 
echo "INICIA EL PROCESO DE START PARA PROCESO SAG" 
date 													   
echo "==================================================="

iniciproceso

#================================================================
# Inicializando variables
#================================================================

respuesta=1
timesleep=$TIEMPOSLEEP
numpausas=1

#================================================================
# ciclo para validacion del servicio
#================================================================
while [ $respuesta -eq 1 ]
do	
	sleep $timesleep
	echo "===================================================" 
	echo "ITERACION: $numpausas" 
	date 													   
	echo "==================================================="	
	
	if [ $numpausas -eq 6 ]; then	
		echo "===================================================" 
		echo "HAN PASADO 3 MINUTOS SE PROCEDE A EJECUTA COMANDO: $PRIMER_START" 
		date 													   
		echo "==================================================="	
		$PRIMER_START
	fi	
	
	if [ $numpausas -ge 10 ]; then
		echo "===================================================" 
		echo "TIEMPO EXCEDIDO AL LEVANTAR SAG" 
		date 													   
		echo "==================================================="
		exit 1
	fi
	validacionstatus "$ESTATUS_START" 
	respuesta=$?
	numpausas=$((numpausas+1))
	
done


#================================================================
# Finalizacion exitosa del servicio
#================================================================

echo "===================================================" 
echo "EL PROCESO DE SAG LEVANTO DE MANERA CORRECTA" 
date 													   
echo "==================================================="
exit 0