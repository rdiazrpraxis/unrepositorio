#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_jboss_eap4.sh
#%
#% DESCRIPTION
#%     Script para iniciar JBOSS
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_jboss_eap4.sh  0.0.0
#-    author          Eric Alejandro Macías Moreno
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : mzme@praxisglobe.com : Script creation 
# 

#================================================================
#	INCIA PROCESO JBOSS
#================================================================
BASEDIR=$(dirname $(readlink -f $0))

. $BASEDIR/common/setenv.sh

echo "===================================================" &>> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4
echo "              INICIANDO PROCESO JBOSS              " &>> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4
echo "                                                   " &>> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4
echo "Script inicia proceso JBOSS inicia: - "$(date) >> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4
echo "                                                  " &>> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4		

$BASEDIR/jboss/$START_SERVICE_JBOSS_EAP4 &>> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4
resultado=$?

#VALIDA SI PROCESO SE EJECUTA CON EXITO
if [ $resultado -eq 0 ]
  then
	echo "Proceso terminado con exito - "$(date) >> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4
	exit 0
  else
	echo "Proceso terminado sin exito - "$(date) >> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4
	exit 1
fi
echo "===================================================" >> $BASEDIR/log/$LOG_START_SERVICE_JBOSS_EAP4

