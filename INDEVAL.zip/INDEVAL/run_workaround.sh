#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    run_workaround.sh
#%
#% DESCRIPTION
#%     Script para Ejecuta Word Around del match
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         run_workaround.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 

BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIALWORKARROUND=`pwd`

. $BASEDIR/common/setenv.sh


#================================================================
# Inicia Fase 0
#================================================================

$ARCHIVOFASE0 &>> $LOG_WORKARROUND
FASE0=$?
if [ "$FASE0" -ne "0" ] 
then
	echo "$FASE0"
	exit 1
fi

#================================================================
# Inicia Fase 1
#================================================================
$ARCHIVOFASE1 &>> $LOG_WORKARROUND
FASE1=$?
if [ "$FASE1" -ne "0" ] 
then
	echo "$FASE1"
	exit 1
fi



#================================================================
# Inicia Fase 2
#================================================================
$ARCHIVOFASE2 &>> $LOG_WORKARROUND
FASE2=$?
if [ "$FASE2" -ne "0" ] 
then
	echo "$FASE2"
	exit 1
fi