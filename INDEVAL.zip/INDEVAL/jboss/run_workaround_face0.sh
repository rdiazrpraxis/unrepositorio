#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    run_workaround_face0.sh
#%
#% DESCRIPTION
#%     Script para detener instancias A Y C
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         run_workaround_face0.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 


#Seteo de variables

BASEDIR=$(dirname $(readlink -f $0))

RUTAINICIALWORKARROUND=$BASEDIR

. $BASEDIR/../common/setenv.sh		



#================================================================
# Funcion que valida que el proceso esta en levantado
# En caso de estar levantado lo mata despues de 20 iteraciones
#================================================================

validaproceso()
{
	PROCESOVALIDA="$1"
	ATTEMPTS=0
	MAX_ATTEMPTS=20
	PS=`ps -fea | grep $PROCESOVALIDA |  grep 'java' | grep -v 'grep' | awk '{ print $2 }'`
	
	while [ -n "$PS" ]
	do
		PS=`ps -fea | grep $PROCESOVALIDA |  grep 'java' | grep -v 'grep'  | awk '{ print $2 }'`
		
		sleep 1		
		ATTEMPTS=$(( $ATTEMPTS + 1 ))
		echo "WAITING $ATTEMPTS SEC"
		if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
			then
			echo "===================================================" 
			echo "SE PROCEDE A MATAR PROCESO DE INSTANCIA A PID= $PS" 
			date 													   
			echo "==================================================="
			if [ -n "$PS" ];then
				kill -9 $PS
			fi	
			return 0
		fi
	done
	return 0
}


#================================================================
# Inicio de proceso
#================================================================

echo "===================================================" 
echo "INCIA PROCESO DE DETENER RUN_WORKARROUND FASE 0  " 
date 													   
echo "==================================================="

echo "===================================================" 
echo "SE PROCEDE A MONITOREAR PROCESOS DE JBOSS INSTANCIA A" 
date 													   
echo "==================================================="


#===============================================================
# Procede a detener el grupo de instancias
#===============================================================
comando_cli=$($HOME_JBOSS/jboss-cli.sh --connect --controller=$JBOSS_CONTROLLER --user=$JBOSS_USER --password=$JBOSS_PASS --commands="$DETIENEINSTANCIAS")
salida=$(echo $comando_cli | awk '{ print $7 }')


echo "===================================================" 
echo "RESPUESTA JBOSS: $salida" 
date 													   
echo "===================================================" 

#===============================================================
# Validacion que instancia A no este levantado
#===============================================================
validaproceso "$PROCESOINSTANCIA_A"

#===============================================================
# Validacion que instancia C no este levantado
#===============================================================

ssh $USUARIOINSTANCIA_C@$INSTANCIA_C $ARCHIVOFASE0_1
RESPUESTA=$?

echo "===================================================" 
echo "TERMINA PROCESO DE DETENER RUN_WORKARROUND FASE 0 " 
date 													   
echo "==================================================="
echo ""
echo ""

exit $RESPUESTA





