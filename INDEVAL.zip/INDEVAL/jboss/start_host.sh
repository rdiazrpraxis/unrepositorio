#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_host.sh
#%
#% DESCRIPTION
#%     Script para levantar jboss de HOST'S A,B,C,D
#% PARAMETERS: 
#%      In:
#%			PARAM $1:
#%				A: procesa HOST A		
#%				B: procesa HOST B
#%				C: procesa HOST C
#%				D: procesa HOST D
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_host.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 

HOST="$1"
 
#================================================================
# Validacion de parametro de entrada
#================================================================

if [ -z  "${HOST}" ]; then
	echo "Falta proporcionar un parametro dede de ser  A o B o C o D" 
	echo "Ejemplo: start_host.sh A " 
	exit 1
fi


#================================================================
# Inicializacion de variables de entorno
#================================================================
#if [ "$HOST" != "$HOST_A" ]; then
	
	BASEDIR=$(dirname $(readlink -f $0))
	RUTAINICIAL=$BASEDIR
	. $BASEDIR/../common/setenv.sh		
#fi


if 	[ "$HOST" != "$HOST_A" ] && 
	[ "$HOST" != "$HOST_B" ] && 
	[ "$HOST" != "$HOST_C" ] && 
	[ "$HOST" != "$HOST_D" ];then
	echo "El parametro de entra es invalido debe de ser  A o B o C o D"
	echo "Ejemplo: start_host.sh A "
	exit 1
fi



#================================================================
# Validación de subprocesos
#================================================================

validasubprocesosjboss()
{

	NOMBREPROCESO=$1
	for NOMPROC in $NOMBREPROCESO
	do 	
			
				
		NOMBREPROCESO="$NOMPROC"
		echo "===================================================" 
		echo "INICIANDO MONITOREO DE PROCESO $PROCESOHOST SUBPROCESO SECUNDARIOS $NOMBREPROCESO" 
		date 													   
		echo "==================================================="	 
		PIDHOST=`ps -fea | grep $NOMPROC | grep 'java' | grep -v 'grep' | awk '{ print $2 }'`	
		SALIDA=0
		if [ -z "$PIDHOST" ] 
			then		
			ATTEMPTS=0
			MAX_ATTEMPTS=20
			PID=""
			while [ -z "$PID"  ]
			do
				sleep 1
				PID=`ps -fea | grep $NOMPROC | grep 'java' | grep -v 'grep' | awk '{ print $2 }'`
				ATTEMPTS=$(( $ATTEMPTS + 1 ))
				echo "WAITING $ATTEMPTS SEC"
				if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
					then
					
					PID='-10000'
					SALIDA=1
				fi
			done
		else 		
			SALIDA=0
		fi


		if [ $SALIDA -eq 0 ]; then
			
			echo "===================================================" 
			echo "EL PROCESO $PROCESOHOST SUBPROCESO SECUNDARIO $NOMBREPROCESO YA SE ENCUENTRA EN EJECUCION" 
			date 													   
			echo "===================================================" 
			echo ""
			echo ""
			echo ""
		else
			echo "===================================================" 
			echo "ERROR: TIEMPO EXCEDIDO DE MONITOREO DEL PROCESO $PROCESOHOST SUBPROCESO SECUNDARIO $NOMBREPROCESO" 
			date 													   
			echo "===================================================" 
			echo ""
			echo ""
			echo ""			
			exit 1

		fi
			 
	done 	
	
}


monitorprocesos()
{
	
	PROCESOPADRE="$1"
	SUBPROCESO="$2"
	NOMBREPROCESO="$3"
	
	echo "===================================================" 
	echo "INICIANDO MONITOREO DE SUBPROCESO PRINCIPAL $NOMBREPROCESO" 
	date 													   
	echo "==================================================="	 
	
	PIDHOST=`ps -ef | grep "$PROCESOPADRE" | grep "$SUBPROCESO" | grep 'java' | grep -v 'grep' | awk '{ print $2 }' `
	SALIDA=0
	if [ -z "$PIDHOST" ] 
		then		
		ATTEMPTS=0
		MAX_ATTEMPTS=20
		PID=""
		while [ -z "$PID"  ]
		do
			sleep 1
			PID=`ps -ef | grep "$PROCESOPADRE" | grep "$SUBPROCESO" | grep 'java' | grep -v 'grep' | awk '{ print $2 }'`			
			ATTEMPTS=$(( $ATTEMPTS + 1 ))
			echo "WAITING $ATTEMPTS SEC"
			if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
				then
				
				PID='-10000'
				SALIDA=1
			fi
		done
	else 		
		SALIDA=0
	fi


	if [ $SALIDA -eq 0 ]; then
		
		echo "===================================================" 
		echo "EL SUBPROCESO PRINCIPAL $NOMBREPROCESO YA SE ENCUENTRA EN EJECUCION" 
		date 													   
		echo "===================================================" 
		echo ""
		echo ""
		echo ""
	else
		echo "===================================================" 
		echo "ERROR: TIEMPO EXCEDIDO DE MONITOREO DEL SUBPROCESO PRINCIPAL $NOMBREPROCESO" 
		date 													   
		echo "===================================================" 
		echo ""
		echo ""
		echo ""		
		exit 1

	fi
	
}


#================================================================
# Funcion para levantar y/o validar servicios de jboss
#================================================================
levantavalidajboss()
{
	NOMBREPROCESO="$1"
	COMANDOEJECTAR="$2"
	echo "===================================================" 
	echo "INICIANDO CON PROCESO PARA LEVANTAR $NOMBREPROCESO  EN FECHA: " 
	date 													   
	echo "===================================================" 

	PIDHOST=`ps -fea | grep $NOMBREPROCESO |  grep -v 'grep'  | awk '{ print $2 }'`
	SALIDA=0
	if [ -z "$PIDHOST" ] 
		then
		
		if [ -n "$COMANDOEJECTAR" ]; then		
			echo "Comando a ejecutar: " $COMANDOSTART 
			echo "Se ejecuta comando start" 
			$COMANDOEJECTAR
			sleep 40
		fi
		ATTEMPTS=0
		MAX_ATTEMPTS=20
		PID=""
		while [ -z "$PID"  ]
		do
			sleep 1
			PID=`ps -fea | grep $NOMBREPROCESO |  grep -v 'grep'  | awk '{ print $2 }'`
			ATTEMPTS=$(( $ATTEMPTS + 1 ))
			echo "WAITING $ATTEMPTS SEC"
			if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
				then
				
				PID='-10000'
				SALIDA=1
			fi
		done
	else 		
		SALIDA=0
	fi


	if [ $SALIDA -eq 0 ]; then
		
		echo "===================================================" 
		echo "EL PROCESO $NOMBREPROCESO LEVANTO CORRECTAMENTE" 
		date 													   
		echo "===================================================" 
		echo ""
		echo ""
		echo ""
	else
		echo "===================================================" 
		echo "OCURRIO UN ERROR AL LEVANTAR EL PROCESO $NOMBREPROCESO" 
		date 													   
		echo "===================================================" 
		echo ""
		echo ""
		echo ""
		exit 1
	fi
	
}

#================================================================
# Se inicia proceso para levantar jboss
#================================================================
levantavalidajboss "$PROCESOHOST" "$COMANDOSTART"

#================================================================
# Se termina proceso para levantar jboss
#================================================================


#================================================================
# Se inicia monitoreo de sub procesos principales jboss
#================================================================

monitorprocesos "$PROCESOHOST" "$CONTROLPROCESO" "$PROCESOHOST $CONTROLPROCESO"
monitorprocesos "$PROCESOHOST" "$CONTROLHOST"  "$PROCESOHOST $CONTROLHOST"

#================================================================
# Se termina monitoreo sub procesos principales jboss
#================================================================

#================================================================
# Se inicia monitoreo de sub procesos secundarios jboss
#================================================================

if 	 [ "$HOST" = "$HOST_A" ];then
	validasubprocesosjboss "$PROCESOSA"
elif [ "$HOST" = "$HOST_B" ];then
	validasubprocesosjboss "$PROCESOSB"
elif [ "$HOST" = "$HOST_C" ];then
	validasubprocesosjboss "$PROCESOSC"
elif [ "$HOST" = "$HOST_D" ];then
	validasubprocesosjboss "$PROCESOSD"
fi

#================================================================
# Se termina monitoreo de sub procesos secundarios jboss
#================================================================


exit $SALIDA 
