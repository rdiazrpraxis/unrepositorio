#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    run_workaround_face0_1.sh
#%
#% DESCRIPTION
#%     Script para detener instancia C
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         run_workaround_face0_1.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 



#####Seteo de Variables de Entorno

BASEDIR=$(dirname $(readlink -f $0))

RUTAINICIALWORKARROUND=$BASEDIR

. $BASEDIR/../common/setenv.sh	

#================================================================
# Funcion que valida que el proceso esta en levantado
# En caso de estar levantado lo mata despues de 20 iteraciones
#================================================================

validaproceso()
{
	PROCESOVALIDA="$1"
	ATTEMPTS=0
	MAX_ATTEMPTS=20
	PS=`ps -fea | grep $PROCESOVALIDA |  grep 'java' | grep -v 'grep' | awk '{ print $2 }'`
	
	while [ -n "$PS" ]
	do
		PS=`ps -fea | grep $PROCESOVALIDA |  grep 'java' | grep -v 'grep'  | awk '{ print $2 }'`
		
		sleep 1		
		ATTEMPTS=$(( $ATTEMPTS + 1 ))
		echo "WAITING $ATTEMPTS SEC"
		if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
			then
			echo "===================================================" 
			echo "SE PROCEDE A MATAR PROCESO DE INSTANCIA C PID= $PS" 
			date 													   
			echo "==================================================="
			kill -9 $PS
			exit 0
		fi
	done
	exit 0
}

echo "===================================================" 
echo "SE PROCEDE A MONITOREAR PROCESOS DE JBOSS INSTANCIA C" 
date 													   
echo "==================================================="

#===============================================================
# Validacion que instancia C no este levantado
#===============================================================

validaproceso "$PROCESOINSTANCIA_C"
