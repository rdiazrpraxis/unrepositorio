#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_ctl_inventarios.sh
#%
#% DESCRIPTION
#%     Script para detener instancias A Y C
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_ctl_inventarios.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 


#Seteo de variables

BASEDIR=$(dirname $(readlink -f $0))

RUTAINICIALWORKARROUND=$BASEDIR

. $BASEDIR/../common/setenv.sh	

#================================================================
# Funcion que valida proceso para detener proceso de control inventario
# 
#================================================================

validaproceso()
{
	PROCESOVALIDA="$1"
	ATTEMPTS=0
	MAX_ATTEMPTS=20
	PS=`ps -fea | grep $PROCESOVALIDA |  grep 'java' | grep -v 'grep' | awk '{ print $2 }'`	

	if [ -n "$PS" ]; then
		echo "==================================================="
		echo "EXISTE EL PID=$PS DE CONTROL INVENTARIOS" 			
		echo "SE PROCEDE A MATAR PROCESO PID= $PS" 
		date 													   
		echo "==================================================="
		kill -9 $PS
	else
		echo "==================================================="					
		echo "NO EXISTE PROCESO " 
		date 													   
		echo "==================================================="		
		
	fi

	return 0
}
 
#================================================================
# Inicio de proceso 
#================================================================ 

echo "==================================================="					
echo "INICIA PROCESO PARA DETENER CONTROL DE INVENTARIOS " 
date 													   
echo "==================================================="
 
#================================================================
# Validacion para detener el proceso 
#================================================================  
validaproceso "$PROCESOSSTANDALONEINVENTARIO"
RESPUESTA=$?
echo "==================================================="					
echo "TERMINA PROCESO PARA DETENER CONTROL DE INVENTARIOS " 
date 													   
echo "===================================================" 

#================================================================
# Terminacion de proceso 
#================================================================ 

exit $RESPUESTA