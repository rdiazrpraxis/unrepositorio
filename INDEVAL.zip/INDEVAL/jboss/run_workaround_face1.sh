#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    run_workaround_face1.sh
#%
#% DESCRIPTION
#%     Script para levantar Jboss Instancia A
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         run_workaround_face1.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 


#===============================================================
# Seteo de variables
#===============================================================

BASEDIR=$(dirname $(readlink -f $0))

RUTAINICIALWORKARROUND=$BASEDIR

. $BASEDIR/../common/setenv.sh	


#===============================================================
# Funcion para validar estatus de instancia
#===============================================================
validastatusproceso()
{
	comando_cli=$($HOME_JBOSS/jboss-cli.sh --connect --controller=$JBOSS_CONTROLLER --user=$JBOSS_USER --password=$JBOSS_PASS --commands="$ESTATUS_A_FASE1")
	salida=$(echo $comando_cli | awk '{ print $7 }')
	
	case $salida in
		\"STARTED\") 
					echo "started"				
				;;
		\"STARTING\") 
					echo "starting"
					
				;;
		\"DISABLED\") 
					echo "disabled"
					
				;;
		\"FAILED\") 
					echo "failed"
					
				;;
				*) 
					echo "inconsistente"					
				;;
		esac	
}

#===============================================================
# Inicio de proceso
#===============================================================

echo "===================================================" 
echo "INCIA PROCESO DE LEVANTAR RUN_WORKARROUND FASE 1  " 
date 													   
echo "==================================================="

echo ""
echo ""

#===============================================================
# Procede a Levantar instancia A
#===============================================================

comando_cli=$($HOME_JBOSS/jboss-cli.sh --connect --controller=$JBOSS_CONTROLLER --user=$JBOSS_USER --password=$JBOSS_PASS --commands="$START_A_FASE1")
salida=$(echo $comando_cli | awk '{ print $7 }')
sleep 30

ciclos=0
limiteciclos=20

echo "===================================================" 
echo "INCIA MONITOREO PARA LEVANTAR RUN_WORKARROUND INSTANCIA A FASE 1  " 
date 													   
echo "==================================================="

#===============================================================
# Procede validar estatus del proceso
#===============================================================

RESPUESTA=$(validastatusproceso)
while [ "$RESPUESTA" != started ];
do
	RESPUESTA=$(validastatusproceso)
	
	echo "===================================================" 
	echo "RESPUESTA JBOSS: $RESPUESTA"  
	echo "WAITING $ciclos SEC"
	date														   
	echo "==================================================="
	sleep 1
	
	ciclos=$((ciclos+1))
	if [ $ciclos -eq $limiteciclos ]; then
	
		echo "===================================================" 
		echo "ERROR: TIEMPO EXCEDIDO DE MONITOREO PARA LEVANTAR INSTANCIA A $PROCESOINSTANCIA_A " 
		date 													   
		echo "==================================================="
		exit 1
	fi
done

echo "===================================================" 
echo "SE LEVANTO DE MANERA CORRECTA JBOSS INSTANCA A  " 
date 													   
echo "==================================================="

#===============================================================
# El proceso se levanto de manera correcta
#===============================================================

echo "===================================================" 
echo "TERMINA PROCESO DE LEVANTAR RUN_WORKARROUND INSTANCIA A FASE 1   " 
date 													   
echo "==================================================="

echo ""
echo ""
exit 0
