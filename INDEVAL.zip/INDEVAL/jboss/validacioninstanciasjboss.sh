#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    validacioninstanciasjboss.sh
#%
#% DESCRIPTION
#%     Script para Validar jboss los procesos de JBOOS levantados
#% PARAMETERS: 
#%      In:
#%			PARAM $1:
#%				A: procesa HOST A		
#%				B: procesa HOST B
#%				C: procesa HOST C
#%				D: procesa HOST D
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_host.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 



HOST="$1"
 
#================================================================
# Validacion de parametro de entrada
#================================================================

if [ -z  "${HOST}" ]; then
	echo "Falta proporcionar un parametro dede de ser  A o B o C o D" 
	echo "Ejemplo: start_host.sh A " 
	exit 1
fi


#================================================================
# Inicializacion de variables de entorno
#================================================================

BASEDIR=$(dirname $(readlink -f $0))
RUTAINICIAL=$BASEDIR
. $BASEDIR/../common/setenv.sh		



if 	[ "$HOST" != "$HOST_A" ] && 
	[ "$HOST" != "$HOST_B" ] && 
	[ "$HOST" != "$HOST_C" ] && 
	[ "$HOST" != "$HOST_D" ];then
	echo "El parametro de entra es invalido debe de ser  A o B o C o D"
	echo "Ejemplo: start_host.sh A "
	exit 1
fi

#================================================================
# Configura procesos a evaluar dependiendo del HOST a validar
#================================================================

if [ "$HOST" = "$HOST_A" ];then
	PROCESOS="$PROCESOSA"
elif [ "$HOST" = "$HOST_B" ];then
	PROCESOS="$PROCESOSB"
elif [ "$HOST" = "$HOST_C" ];then
	PROCESOS="$PROCESOSC"
elif [ "$HOST" = "$HOST_D" ];then
	PROCESOS="$PROCESOSD"
fi



#================================================================
# Inicia con validacion de las instancias
#================================================================
intentos=$INTENTOS
while [ $intentos -le $LIMITEINTENTOS ];
 do
	
	echo "===================================================" 
	echo "INICIANDO VALIDACION INSTANCIAS DEL $HOST NUMERO DE INTENTO: $intentos" 
	date 													   
	echo "==================================================="	 
	echo ""
	echo ""
	for nomproceso in $PROCESOS
	do 		
		echo "	===================================================" 
		echo "	VALIDANDO HOST: $HOST DE INSTANCIA: $nomproceso" 
		fecha=`date`
		echo "       " $fecha 													   
		echo "	==================================================="	
		
		#================================================================
		# Analiza por medio de consola JBOSS estatus actual de intancia
		#================================================================
		comando_cli=$($HOME_JBOSS/jboss-cli.sh --connect --controller=$JBOSS_CONTROLLER --user=$JBOSS_USER --password=$JBOSS_PASS --commands="/host=Host-Dali-Web-$HOST/server-config=$nomproceso:read-attribute(name=status)")
		salida=$(echo $comando_cli | awk '{ print $7 }')
		
		
		#================================================================
		# Muestra cual es el estatus actual de la instancia
		#================================================================
		echo "	COMANDO: $comando_cli"
		case $salida in
			\"STARTED\") 
						echo  "	$nomproceso  started"						
						#exit 0
					;;
			\"STARTING\") 
						echo "	$nomproceso starting"
						#exit 1
					;;
			\"DISABLED\") 
						echo "	$nomproceso  disabled"
						#exit 2
					;;
			\"FAILED\") 
						echo   "	$nomproceso failed"
						#exit 10
					;;
					*) 
						echo "	$nomproceso inconsistente"
						#exit 200
					;;
		esac	
		echo "	===================================================" 
		echo "	TERMINA VALIDACION DE HOST: $HOST DE INSTANCIA: $nomproceso"  
		fecha=`date`
		echo "       " $fecha 													   
		echo "	==================================================="
		echo ""
		echo ""
	done 
	
	echo "===================================================" 
	echo "TERMINANDO VALIDACION INSTANCIAS DEL $HOST NUMERO DE INTENTO: $intentos" 
	date 													   
	echo "==================================================="	 
	echo ""
	echo ""
	intentos=$((intentos+1))
done 

#================================================================
# Termino con validacion de las instancias
#================================================================

