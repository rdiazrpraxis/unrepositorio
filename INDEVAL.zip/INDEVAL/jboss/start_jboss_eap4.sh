#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_jboss_eap4.sh
#%
#% DESCRIPTION
#%     Script que inicia procesos JBOSS
#%	   
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_jboss_eap4.sh  0.0.0
#-    author          Eric Alejandro Macías Moreno
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : mzme@praxisglobe.com : Script creation
# 
echo '############################################################'
echo '#################Iniciando Proceso Jboss 4####################'
echo '############################################################'

BASEDIR=$(dirname $(readlink -f $0))
$BASEDIR/../common/setenv.sh

echo "Iniciando proceso Jboss 4"

PIDHOST=`ps -fea | grep $CCV_PROCESS_JBOSS | grep -v 'grep' | awk '{ print $2 }'`
	if [[ -z "$PIDHOST" ]] 
		then
		$START_PROCESS_JBOSS
		

		ATTEMPTS=0
		MAX_ATTEMPTS=10
		while [ -z "$PID"  ]
		do
			sleep 1
			PID=`ps -fea | grep $CCV_PROCESS_JBOSS | grep -v 'grep' | awk '{ print $2 }'`
			ATTEMPTS=$(( $ATTEMPTS + 1 ))
			echo "ESPERE $ATTEMPTS SEGUNDOS"
			if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
				then
				echo "El proceso Jboss4 tarda mucho, El Proceso  ${CCV_PROCESS_JBOSS} no pudo iniciar correctamente"
				PID='-10000'
				exit 1
			fi
		done
        
	else 
		echo " EL PROCESO $CCV_PROCESS_JBOSS con $PIDHOST ya se encuentra Arriba, nada que hacer...."
		exit 0
	fi
