#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    run_workaround_face2.sh
#%
#% DESCRIPTION
#%     Script para para levantar Jboss Instancia C
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         run_workaround_face2.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 


#===============================================================
# Seteo de variables
#===============================================================

BASEDIR=$(dirname $(readlink -f $0))

RUTAINICIALWORKARROUND=$BASEDIR

. $BASEDIR/../common/setenv.sh	



#===============================================================
# Funcion para validar estatus de instancia
#===============================================================

validastatusproceso()
{
	comando_cli=$($HOME_JBOSS/jboss-cli.sh --connect --controller=$JBOSS_CONTROLLER --user=$JBOSS_USER --password=$JBOSS_PASS --commands="$ESTATUS_C_FASE2")
	salida=$(echo $comando_cli | awk '{ print $7 }')
	
	case $salida in
		\"STARTED\") 
					echo "started"				
				;;
		\"STARTING\") 
					echo "starting"
					
				;;
		\"DISABLED\") 
					echo "disabled"
					
				;;
		\"FAILED\") 
					echo "failed"
					
				;;
				*) 
					echo "inconsistente"					
				;;
		esac	
}

#===============================================================
# Inicio de proceso
#===============================================================

echo "===================================================" 
echo "INCIA PROCESO DE LEVANTAR RUN_WORKARROUND INSTANCIA C FASE 2  " 
date 													   
echo "==================================================="

echo ""
echo ""

#===============================================================
# Procede a Levantar instancia A
#===============================================================

comando_cli=$($HOME_JBOSS/jboss-cli.sh --connect --controller=$JBOSS_CONTROLLER --user=$JBOSS_USER --password=$JBOSS_PASS --commands="$START_A_FASE2")
salida=$(echo $comando_cli | awk '{ print $7 }')
sleep 15

ciclos=0
limiteciclos=20

#===============================================================
# Procede validar estatus del proceso
#===============================================================

RESPUESTA=$(validastatusproceso)
while [ "$RESPUESTA" != started ];
do
	RESPUESTA=$(validastatusproceso)
	
	echo "===================================================" 
	echo "RESPUESTA JBOSS: $RESPUESTA" 
	echo "WAITING $ciclos SEC"	
	date														   
	echo "==================================================="
	sleep 1
	ciclos=$((ciclos+1))
	if [ $ciclos -eq $limiteciclos ]; then
	
		echo "===================================================" 
		echo "ERROR: TIEMPO EXCEDIDO DE MONITOREO PARA LEVANTAR INSTANCIA C $PROCESOINSTANCIA_C " 
		date 													   
		echo "==================================================="
		exit 1
	fi
done

echo "===================================================" 
echo "SE LEVANTO DE MANERA CORRECTA JBOSS INSTANCA C  " 
date 													   
echo "==================================================="

#===============================================================
# El proceso se levanto de manera correcta
#===============================================================

echo "===================================================" 
echo "TERMINA PROCESO DE LEVANTAR RUN_WORKARROUND  INSTANCIA C FASE 2  " 
date 													   
echo "==================================================="


exit 0
