#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_jboss_eap4.sh
#%
#% DESCRIPTION
#%     Detiene procesos JBOSS
#%	   
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_jboss_eap4.sh  0.0.0
#-    author          Eric Alejandro Macías Moreno
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : mzme@praxisglobe.com : Script creation
# 
echo '############################################################'
echo '#################DETENIENDO PROCESO JBOSS###################'
echo '############################################################'

BASEDIR=$(dirname $(readlink -f $0))
$BASEDIR/../common/setenv.sh

echo "Deteniendo procesos JBOSS"

PIDHOST=`ps -fea | grep $CCV_PROCESS_JBOSS | grep -v 'grep' | awk '{ print $2 }'`
	if [[ -n $PIDHOST ]]
		then		
		echo "Proceso con nombre nombre $CCV_PROCESS_JBOSS con $PIDHOST deteniendo ...."
		kill -9 $PIDHOST

		ATTEMPTS=0
		MAX_ATTEMPTS=15
		while [[ -n "$PID" ]]
		do
			sleep 1
			PID=`ps -fea | grep $CCV_PROCESS_JBOSS | grep -v 'grep' | awk '{ print $2 }'`
			ATTEMPTS=$(( $ATTEMPTS + 1 ))
			echo "ESPERE $ATTEMPTS SEC"
			if [[ $ATTEMPTS -gt $MAX_ATTEMPTS ]]
				then
				echo "mas Tiempo que esperar, El Proceso ${CCV_PROCESS_JBOSS} NO puede detenerse de manera correcta" 
				PID='-10000'
				exit 1
			fi
		done
	else
		if [[ -z $PIDHOST ]]
			then
			echo "No Existe el Proceso de Jboss 4 en ejecucion, Nada que hacer..."
			exit 0
		fi
	fi
