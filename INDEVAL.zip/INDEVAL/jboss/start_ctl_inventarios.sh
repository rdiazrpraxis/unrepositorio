#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_ctl_inventarios.sh
#%
#% DESCRIPTION
#%     Script para levantar servicio de control de inventarios
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_ctl_inventarios.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 


#Seteo de variables

BASEDIR=$(dirname $(readlink -f $0))

RUTAINICIALWORKARROUND=$BASEDIR

. $BASEDIR/../common/setenv.sh		



#================================================================
# Funcion que valida que el proceso esta en levantado
# 
#================================================================

validaproceso()
{
	PROCESOVALIDA="$1"
	ATTEMPTS=0
	MAX_ATTEMPTS=20
	#================================================================
	# Rastrea proceso si esta levantado
	#================================================================
	
	PS=`ps -fea | grep $PROCESOVALIDA |  grep 'java' | grep -v 'grep' | awk '{ print $2 }'`	
	
	#================================================================
	# Si no hay PID procede a levantar servicio 
	#================================================================

	if [ -z "$PS" ]; then

		echo ""
		echo ""
		
		echo "===================================================" 
		echo "INICIA MONITOREO DE PROCESO CONTROL INVENTARIO " 
		date 													   
		echo "==================================================="
		
		echo "===================================================" 
		echo "Se ejecuta comando: $EJECUCION_INVENTARIO_START " 
		date 													   
		echo "==================================================="

		$EJECUCION_INVENTARIO_START
		
		sleep 30
		
	else
		echo "===================================================" 
		echo "EL PROCESO DE CONTROL DE INVENTARIOS YA ESTABA INICIADO  " 
		date 													   
		echo "==================================================="
		return 0
	fi

	#================================================================
	# Inicia monitoreo del servicio que se levanto 
	#================================================================
	while [ -z "$PS" ]
	do
		PS=`ps -fea | grep $PROCESOVALIDA |  grep 'java' | grep -v 'grep'  | awk '{ print $2 }'`		
		sleep 1		
		ATTEMPTS=$(( $ATTEMPTS + 1 ))
		echo "WAITING $ATTEMPTS SEC"
		if [ $ATTEMPTS -gt $MAX_ATTEMPTS ];	then
			echo "===================================================" 
			echo "ERROR: TIEMPO EXCEDIDO DE MONITOREO PARA LEVANTAR INSTANCIA CONTROL INVENTARIOS " 
			date 													   
			echo "==================================================="
			return 1
		fi	
	done
	
	echo ""
	echo ""
	echo "===================================================" 
	echo "EL PROCESO LEVANTO DE MANERA EXITOSA INSTANCIA CONTROL INVENTARIOS" 
	date 													   
	echo "==================================================="
	return 0
}


#================================================================
# Inicio de proceso
#================================================================

echo "===================================================" 
echo "SE INICIA PROCESO DE CONTROL DE INVENTARIOS  " 
date 													   
echo "==================================================="

validaproceso "$PROCESOSSTANDALONEINVENTARIO"
RESPUESTA=$?

echo "===================================================" 
echo "TERMINA MONITOREO DE PROCESO CONTROL INVENTARIO  " 
date 													   
echo "==================================================="

echo ""
echo ""

#================================================================
# Termino de proceso
#================================================================

echo "===================================================" 
echo "SE TERMINA PROCESO DE CONTROL DE INVENTARIOS  " 
date 													   
echo "==================================================="

exit $RESPUESTA





