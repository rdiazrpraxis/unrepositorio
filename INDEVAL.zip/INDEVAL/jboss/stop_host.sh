#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_host.sh
#%
#% DESCRIPTION
#%     Script para detener catalyst
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_host.sh  0.0.0
#-    author          Oliver Figueroa Garcia
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : fxgo@praxisglobe.com : Script creation 
# 

#================================================================
# Setea $BASEDIR
#================================================================

BASEDIR=$(dirname $(readlink -f $0))

#================================================================
# Setea y ejecuta setenv.sh
#================================================================

source $BASEDIR/../common/setenv.sh

#================================================================
# funciones
#================================================================

#Valida si el ultimo proceso es executado con exito o fracasa
valida_proceso(){
  if [ $1 -ne 0 ]
  then
    echo "Fracasó la ejecución del script - "$(date)
  else
    echo "Se ejecutó con éxito el script - "$(date)
  fi
}

ejecuta_ps(){

	unset V_PC
	unset V_HC
	unset PROCESOS

	V_PC=`ps -ef | grep -- $HOST_DALI_WEB$HOST | grep -- "$PROCESS_CONTROLLER" | grep 'java' | grep -v 'grep' | awk '{ print $2 }'`
	V_HC=`ps -ef | grep -- $HOST_DALI_WEB$HOST | grep -- "$HOST_CONTROLLER" | grep 'java' | grep -v 'grep' | awk '{ print $2 }'`
	PROCESOS=`ps -ef | grep -E -- "$PROCESOS_HOST" | grep -v 'grep' | awk '{ print $2 }'`

	if [ ! -n "$V_PC" ] && [ ! -n "$V_HC" ] && [ ! -n "$PROCESOS" ]
		then
			unset V_PC
			unset V_HC
			unset PROCESOS
			# Son nulos = Exito
			return 0
		else
			unset V_PC
			unset V_HC
			unset PROCESOS

			# No son nulos = Fracaso
			return 1
	fi
}

#Valida que los procesos no existan.
valida_proceso_jbosseap(){

	ejecuta_ps
	PS=$?
	if [ "$PS" -eq 1 ]
		then
		echo "Se ejecuta comando: "$COMANDO
		$COMANDO
		comando_stop=$?
		valida_proceso $comando_stop

		ATTEMPTS=0
		MAX_ATTEMPTS=20
		while [ "$PS" -ne 0 ]
		do
			sleep 1
			ejecuta_ps
			PS=$?
			ATTEMPTS=$(( ATTEMPTS + 1 ))
			echo "WAITING $(( MAX_ATTEMPTS - ATTEMPTS)) SEC"
			if [ $ATTEMPTS -ge $MAX_ATTEMPTS ]
				then
				echo "Ocurrio un error al ejecutar: "$COMANDO
				PS=0
			fi
		done
	else 
		echo "No se encuentran corriendo los procesos"
	fi
}

#================================================================
# Inicio
#================================================================
echo '############################################################'
echo '#####################DETENIENDO INDEVAL#####################'
echo '############################################################'

case $1 in
	A)
		HOST=$1
		PROCESOS_HOST=$PROCESOS_HOST_A
		COMANDO=$COMANDO_STOP_HOST_A
		valida_proceso_jbosseap		
	;;
	B)
		HOST=$1
		PROCESOS_HOST=$PROCESOS_HOST_B
		COMANDO=$COMANDO_STOP_HOST_B
		valida_proceso_jbosseap		
	;;
	C)
		HOST=$1
		PROCESOS_HOST=$PROCESOS_HOST_C
		COMANDO=$COMANDO_STOP_HOST_C
		valida_proceso_jbosseap		
	;;
	D)
		HOST=$1
		PROCESOS_HOST=$PROCESOS_HOST_D
		COMANDO=$COMANDO_STOP_HOST_D
		valida_proceso_jbosseap		
	;;
	*)
		echo "Hacen falta argumentos, solo se admiten A,B,C y D"
		exit 0
	;;
esac