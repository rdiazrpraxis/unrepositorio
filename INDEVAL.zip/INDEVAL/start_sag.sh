#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_sag.sh
#%
#% DESCRIPTION
#%     Script para levantar el SAG
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_sag.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 

BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/common/setenv.sh


$ARCHIVO_START &>> $LOG_START
STARTHOST=$?
if [ "$STARTHOST" -ne "0" ] 
then
	echo "$STARTHOST"
	exit 1
fi
