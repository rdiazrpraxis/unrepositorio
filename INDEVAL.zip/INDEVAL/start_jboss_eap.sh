#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_jboss_eap.sh
#%
#% DESCRIPTION
#%     Script para levantar jboos de HOST'S A,B,C,D
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_jboss_eap.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 


BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/common/setenv.sh

 
#================================================================
# Inicia host A
#================================================================


$RUTAJBOSS/$LEVANTAJBOOS $HOST_A &>> $LOG_START
STARTHOST=$?
if [ "$STARTHOST" -ne "0" ] 
then
	echo "$STARTHOST"
	exit 1
fi
#================================================================
# Termina host A
#================================================================

#================================================================
# Inicia host B
#================================================================

ssh $USUARIO@$IP_HOST_B $RUTAJBOSS/$LEVANTAJBOOS $HOST_B &>> $LOG_START
STARTHOST=$?

if [ "$STARTHOST" -ne "0" ] 
then
	echo "$STARTHOST"
	exit 1
fi
#================================================================
# Termina host B
#================================================================

#================================================================
# Inicia host C
#================================================================

ssh $USUARIO@$IP_HOST_C $RUTAJBOSS/$LEVANTAJBOOS $HOST_C &>> $LOG_START
STARTHOST=$?

if [ "$STARTHOST" -ne "0" ] 
then
	echo "$STARTHOST"
	exit 1
fi
#================================================================
# Termina host C
#================================================================


#================================================================
# Inicia host D
#================================================================

ssh $USUARIO@$IP_HOST_D $RUTAJBOSS/$LEVANTAJBOOS $HOST_D &>> $LOG_START
STARTHOST=$?

if [ "$STARTHOST" -ne "0" ] 
then
	echo "$STARTHOST"
	exit 1
fi
#================================================================
# Termina host D
#================================================================


#================================================================
# Inicia  validacion de instancias JBOSS
#================================================================

$VALIDAJBOSS $HOST_A &>> $LOG_START
$VALIDAJBOSS $HOST_B &>> $LOG_START
$VALIDAJBOSS $HOST_C &>> $LOG_START
$VALIDAJBOSS $HOST_D &>> $LOG_START

#================================================================
# Termina validacion de instancias JBOSS
#================================================================