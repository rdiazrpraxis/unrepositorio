#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_jboss_eap.sh
#%
#% DESCRIPTION
#%     Script para detener catalys
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_jboss_eap.sh  0.0.0
#-    author          Oliver Figueroa Garcia
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : fxgo@praxisglobe.com : Script creation 
# 

#================================================================
# Setea $BASEDIR
#================================================================

BASEDIR=$(dirname $(readlink -f $0))

#================================================================
# Setea y ejecuta setenv.sh
#================================================================

source $BASEDIR/common/setenv.sh

#================================================================
# funciones
#================================================================

#Valida si el ultimo proceso es executado con exito o fracasa
valida_proceso(){
  if [ $1 -ne 0 ]
  then
    echo "Fracasó la ejecución - "$(date) >> $BASEDIR/$LOG_STOP_INDEVAL
  else
    echo "Se ejecutó con éxito - "$(date) >> $BASEDIR/$LOG_STOP_INDEVAL
  fi
}

#================================================================
# Inicio
#================================================================

echo '############################################################' &>> $BASEDIR/$LOG_STOP_INDEVAL
echo '############INICIANDO LLAMADOS A SCRIPT STOP################' &>> $BASEDIR/$LOG_STOP_INDEVAL
echo '############################################################' &>> $BASEDIR/$LOG_STOP_INDEVAL

#================================================================
# stop host A
#================================================================
$BASEDIR/$JBOSSEAP_HOST_SCRIPT_STOP $HOST_A &>> $BASEDIR/$LOG_STOP_INDEVAL
stop_a=$?
valida_proceso $stop_a

#================================================================
# stop host B
#================================================================
ssh $USUARIO@$IP_HOST_B "$BASEDIR/$JBOSSEAP_HOST_SCRIPT_STOP $HOST_B" &>> $BASEDIR/$LOG_STOP_INDEVAL
stop_b=$?
valida_proceso $stop_b

#================================================================
# stop host C
#================================================================
ssh $USUARIO@$IP_HOST_C "$BASEDIR/$JBOSSEAP_HOST_SCRIPT_STOP $HOST_C" &>> $BASEDIR/$LOG_STOP_INDEVAL
stop_c=$?
valida_proceso $stop_c

#================================================================
# stop host D
#================================================================
ssh $USUARIO@$IP_HOST_D "$BASEDIR/$JBOSSEAP_HOST_SCRIPT_STOP $HOST_D" &>> $BASEDIR/$LOG_STOP_INDEVAL
stop_d=$?
valida_proceso $stop_d
