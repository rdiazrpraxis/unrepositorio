#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_sag.sh
#%
#% DESCRIPTION
#%     Script para Dar de baja el SAG
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_sag.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 
BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/../common/setenv.sh

#================================================================
# funcion para validacion se estatus de la aplicacion
#================================================================

validacionstatus()
{
	buscastatus="$1"
	estatus=`$VALIDACION_STATUS`
	estatustmp=`echo "$estatus" | grep "$buscastatus"`
	if [ "$estatustmp" != "" ]; then
		return 0
	else 
		return 1
	fi
	
}

#================================================================
# Inicio de validacion de Start SAG
#================================================================
echo "===================================================" 
echo "INICIA EL PROCESO DE STOP PARA PROCESO SAG" 
date 													   
echo "==================================================="

validacionstatus "$ESTATUS_START" 
if [ $? -eq 0 ]; then

	echo "INICIANDO COMANDO: $PRIMER_STOP"
	$PRIMER_STOP
	sleep $TIEMPOSLEEP
fi


#================================================================
# Inicializando variables
#================================================================
Respuesta=1
timesleep=$TIEMPOSLEEP
Numpausas=1

while [ $Respuesta -eq 1 ]
do	
	sleep $timesleep
	echo "===================================================" 
	echo "ITERACION: $Numpausas" 
	date 													   
	echo "==================================================="	
	if [ $Numpausas -eq 12 ]; then	
		echo "===================================================" 
		echo "SE EJECUTA COMANDO: $PRIMER_STOP" 
		date 													   
		echo "==================================================="	
		$PRIMER_STOP
	fi	
	if [ $Numpausas -eq 10 ]; then
		echo "===================================================" 
		echo "HAN PASASO 5 MINUTOS SE PROCEDE SE EJECUTA COMANDO: $SEGUNDO_STOP" 
		date 													   
		echo "==================================================="
		$SEGUNDO_STOP
	fi
	
	if [ $Numpausas -ge 15 ]; then
		echo "===================================================" 
		echo "TIEMPO EXCEDIDO AL DAR DE BAJA SAG" 
		date 													   
		echo "==================================================="
		
		exit 1
	fi
	validacionstatus "$ESTATUS_STOP" 
	Respuesta=$?
	Numpausas=$((Numpausas+1))
	
done

#================================================================
# Finalizacion exitosa del servicio
#================================================================
echo "===================================================" 
echo "EL PROCESO DE SAG DETUVO DE MANERA CORRECTA" 
date 													   
echo "==================================================="

exit 0
