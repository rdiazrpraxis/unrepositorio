#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    setenv.sh
#%
#% DESCRIPTION
#%     Shell encargado de inicializar variables
#%                        
#================================================================


#################
##VARIABLES SAG
export USUARIO="swnet"
export RUTAINICIAL="$RUTAINICIAL"
export FOLDERSAG="$RUTAINICIAL/SAG"
export LOG_START="$RUTAINICIAL/SAG/log/start_sag.log"
export LOG_STOP="$RUTAINICIAL/SAG/log/stop_sag.log"
export ARCHIVO_START="$FOLDERSAG/start_sag.sh"
export ARCHIVO_STOP="$FOLDERSAG/stop_sag.sh"
export ESTATUS_STOP="stopped"
export ESTATUS_START="started"
export COMAND0SPROCESOS="/Alliance/Gateway/bin"
#export COMAND0SPROCESOS="/home/rdiazr"
export PRIMER_START="$COMAND0SPROCESOS/sag_system -block -- start"
export SEGUNDO_START="$COMAND0SPROCESOS/sag_bootstrap start"
export VALIDACION_STATUS="$COMAND0SPROCESOS/sag_system -block -- status"
export TIEMPOSLEEP=30

export PRIMER_STOP="$COMAND0SPROCESOS/sag_system -block -- stop"
export SEGUNDO_STOP="$COMAND0SPROCESOS/sag_bootstrap stop"