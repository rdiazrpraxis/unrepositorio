#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    stop_sag.sh
#%
#% DESCRIPTION
#%     Script para dar de baja SAG
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_sag.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 

BASEDIR=$(dirname $(readlink -f $0))

#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/common/setenv.sh


$ARCHIVO_STOP &>> $LOG_STOP
STOPHOST=$?
if [ "$STOPHOST" -ne "0" ] 
then
	echo "$STOPHOST"
	exit 1
fi

