#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_drt_dali.sh
#%
#% DESCRIPTION
#%     Script para levantar repositorios drt_dali
#% PARAMETERS: 
#%
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         start_drt_dali.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 




BASEDIR=$(dirname $(readlink -f $0))

 
#####Seteo de Variables de Entorno
cd $BASEDIR

RUTAINICIAL=`pwd`

. $BASEDIR/common/setenv.sh




#================================================================
# inicia dali 3
#================================================================



ssh $USUARIO@$IP_DALI_3 $RUTAFUSEREMOTO/$LEVANTADALI $TRES &>> $LOG_DALI
STARTHOST=$?

if [ "$STARTHOST" -ne "0" ] 
then
	echo "$STARTHOST"
	exit 1
fi
#================================================================
# Termina dali 3
#================================================================



#================================================================
# Inicia dali 1
#================================================================

$RUTAFUSE/$LEVANTADALI $UNO &>> $LOG_DALI
STARTHOST=$?

if [ "$STARTHOST" -ne "0" ] 
then
	echo " $STARTHOST"
	exit 1
fi

#================================================================
# Termina dali 1
#================================================================



#================================================================
# inicia dali 2
#================================================================

ssh $USUARIO@$IP_DALI_2 $RUTAFUSEREMOTO/$LEVANTADALI $DOS &>> $LOG_DALI
STARTHOST=$?

if [ "$STARTHOST" -ne "0" ] 
then
	echo "$STARTHOST"
	exit 1
fi

#================================================================
# Termina dali 2
#================================================================
