#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    setenv.sh
#%
#% DESCRIPTION
#%     Shell encargado de inicializar variables
#%			  
#================================================================
#- IMPLEMENTATION
#-    version         setenv.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation
# 




#################
##LEVANTA DALI
export IP_DALI_1="192.168.96.128"
export IP_DALI_2="192.168.96.128"
export IP_DALI_3="192.168.96.128"
export STARTDALI="/soft/app/fuseusr/jboss-fuse-6.2.1/instances/drt_dali"
export STARTCOMPLEMENTO="_*/bin/start"
export LEVANTADALI="start_dali.sh"
export USUARIO="fuseusr"
export BUSCAPROC="drt_dali"
export STARTDALIREMOTO="/soft/app/fuseusr/jboss-fuse-6.2.1/containers/fabric-ccv-qa-${NUMEROPROCESO}/fabric8-karaf-1.2.0.redhat-621107/instances/drt_dali"
export JAVA_HOME="/usr/local/java/jdk1.8.0_221"

export RUTAINICIAL="$RUTAINICIAL"
export RUTAFUSE="${RUTAINICIAL}/fuse"
export LOG_DALI="$RUTAINICIAL/log/start_drt_dali.log"
export PATHREMOTO="$RUTAINICIAL"
export RUTAFUSEREMOTO="$PATHREMOTO/fuse"

export UNO="1"
export DOS="2"
export TRES="3"

#################
##DETENER DALI
export DETIENEDALI="stop_dali.sh"
export LOG_DETIENE_DALI="$RUTAINICIAL/log/stop_drt_dali.log"
export STOPDALI="/soft/app/fuseusr/jboss-fuse-6.2.1/instances/drt_dali"
export STOPCOMPLEMENTO="_*/bin/stop"
