#!/bin/sh
#================================================================
# HEADER
#================================================================
#% SYNOPSIS
#+    start_dali.sh
#%
#% DESCRIPTION
#%     Script para detener repositorios drt_dali
#% PARAMETERS: 
#%      In:
#%			PARAM $1:
#%				1: procesa DRT_DALI 1		
#%				2: procesa DRT_DALI 2		
#%				3: procesa DRT_DALI 3		
#%    	Out:
#%			0: Exito
#%		   	1: Error
#================================================================
#- IMPLEMENTATION
#-    version         stop_dali.sh  0.0.0
#-    author          Ricardo Diaz Reyes
#-    copyright       Copyright (c) BMV
#-
#================================================================
#  HISTORY
#     2020/06/10 : dirr@praxis.com.mx : Script creation 
# 

NUMEROPROCESO="$1"

#================================================================
# Validacion de parametro de entrada
#================================================================


if [ -z  "${NUMEROPROCESO}" ]; then
	echo "Falta proporcionar un parameteo que sea 1 o 2 o 3" 
	echo "Ejemplo: start_dali.sh 1 " 
	exit 1
fi

if [ "${NUMEROPROCESO}" -gt 4 ];then
	echo "Parametro invalido solo es del 1 o 2 o 3 " 
	exit 1
fi

pwd
if [ $NUMEROPROCESO -gt 1 ]; then
	BASEDIR=$(dirname $(readlink -f $0))
	RUTAINICIAL=$BASEDIR
	. $BASEDIR/../common/setenv.sh	
fi






#================================================================
# Se inicia proceso para detener servicio
#================================================================
echo ""
echo ""
echo ""

echo "===================================================" 
echo "INICIANDO CON PROCESO PARA DETENER DRT_DALI$NUMEROPROCESO  EN FECHA: " 
date 													   
echo "===================================================" 

echo "Comando a ejecutar: " $STOPDALI$NUMEROPROCESO$STOPCOMPLEMENTO 


NOMBREPROCESO="${BUSCAPROC}${NUMEROPROCESO}_*"

PIDHOST=`ps -fea | grep $NOMBREPROCESO |  grep -v 'grep'  | awk '{ print $2 }'`

if [ -n "$PIDHOST" ] 
	then
	echo "Se ejecuta comando stop" 
	$STOPDALI$NUMEROPROCESO$STOPCOMPLEMENTO 

	ATTEMPTS=0
	MAX_ATTEMPTS=20
	while [ -n "$PID"  ]
	do
		sleep 1
		PID=`ps -fea | grep $NOMBREPROCESO |  grep -v 'grep'  | awk '{ print $2 }'`
		ATTEMPTS=$(( $ATTEMPTS + 1 ))
		echo "WAITING $ATTEMPTS SEC"
		if [ $ATTEMPTS -gt $MAX_ATTEMPTS ]
			then
	
			PID='-10000'
			SALIDA=1
		fi
	done
else 
	SALIDA=0
fi



#================================================================
# Se termina proceso para detener servicio y validamos si fue exitoso
#================================================================


if [ "$SALIDA" -eq 0 ]; then
	
	echo "===================================================" 
	echo "El Contenedor drt_dali de detuvo  Correctamente DRT_DALI$NUMEROPROCESO" 
	date 													   
	echo "===================================================" 
	
else
	echo "===================================================" 
	echo "Ocurrio un Error al detener el Contenedor drt_dali DRT_DALI$NUMEROPROCESO" 
	date 													   
	echo "===================================================" 

fi

echo "" 
echo "" 
echo "" 
exit $SALIDA


